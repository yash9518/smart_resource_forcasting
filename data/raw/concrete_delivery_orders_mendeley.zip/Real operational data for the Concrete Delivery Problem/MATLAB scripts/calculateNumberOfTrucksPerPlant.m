%-------------------------------------------------------------------------%
%  Calculating the number of trucks of a specific capacity at each Plant  %
%                                                                         %
% Run this file to calculate the number of trucks of a specific capacity  %
% at each Plant.                                                          %
%                                                                         %
% Output:                                                                 %
% - AvailableTrucksPerPlant : a table containing the number of trucks of  %
%                             each capacity (columns) at each Plant (rows)%
%                                                                         %
% This script:                                                            %
%   a) loads the required tables by asking the user to locate them in the %
%      folders                                                            %
%   b) calculates how many trucks of each capacity type exist at each     %
%      Plant                                                              %
%   c) creates the AvailableTrucksPerPlant table containing the           %
%      information above and asks the user to save the output             %
%                                                                         %
% by:                 Alexandros Tzanetos  © 2023                         %
%-------------------------------------------------------------------------%

%% Loading the Plants information

% Locate the mat-file including the Plants data:
disp('Select the file "Plants.mat".')
[Plants_fileName, Plants_filePath] = uigetfile('*.mat','Select the file "Plants.mat".');
Plants_fullFileName = fullfile(Plants_filePath, Plants_fileName);

% Loading the table LoadingRates which contains the Plants' pseudoID:
load(Plants_fullFileName,'LoadingRates')

%% Loading the Concrete Delivery Trucks information

% Locate the mat-file including the Fleet data:
disp('Select the file "Fleet_data.mat".')
[Fleet_fileName, Fleet_filePath] = uigetfile('*.mat','Select the file "Fleet_data.mat".');
Fleet_fullFileName = fullfile(Fleet_filePath, Fleet_fileName);

% Loading the table LoadingRates which contains the Plants' pseudoID:
load(Fleet_fullFileName,'ConcreteDeliveryTrucks')

%% Calculate the number of trucks of a specific capacity at each Plant

% Find the unique values in Trucks' Capacities
uniqueCapacities = unique(ConcreteDeliveryTrucks.Capacity,'rows');

% Create a table showing the number of trucks of each capacity type at each Plant.
AvailableTrucksPerPlant = array2table(zeros(height(LoadingRates),length(uniqueCapacities)),...
                                      'VariableNames',...
                                      cellstr(string(uniqueCapacities)));

% Fill the table:
for plant = 1:height(LoadingRates)
    for capacity = 1:length(uniqueCapacities)
        AvailableTrucksPerPlant(plant,string(uniqueCapacities(capacity))) =  ...
            num2cell(sum(ConcreteDeliveryTrucks.PlantID == LoadingRates.PlantID(plant) & ...
                         ConcreteDeliveryTrucks.Capacity == uniqueCapacities(capacity)));
    end
end

%% Save the output
answer = questdlg('Do you want to save the output into the Fleet_data.mat?',...
                  'Saving Output',...
                  'YES','No, thank you','No, thank you');
switch answer
    case 'YES'
        save('Fleet_Data.mat','AvailableTrucksPerPlant','-append')
    case 'NO'
        return
end