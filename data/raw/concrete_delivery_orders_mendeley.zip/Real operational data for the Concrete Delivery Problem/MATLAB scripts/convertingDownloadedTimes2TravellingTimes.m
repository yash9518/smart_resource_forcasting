%-------------------------------------------------------------------------%
%   Converting Downloaded Times to (minutes duration) Travelling Times    %
%                                                                         %
% Run this file to process the raw data consisting in .xlsx corresponding %
% to travelling time between Production Sites and Plants.                 %
%                                                                         %
% Inputs:                                                                 %
% - TravellingTimes          : the downloaded travelling times from Google%
%                              API with format "H hour(s) MM min(s)".     %
% Outputs:                                                                %
% - TravellingTimesConverted : the final travelling times to be saved in  %
%                              the instances.                             %
%                                                                         %
% This script:                                                            %
%   a) gets a string table as input                                       %
%   b) omits any "min" or "mins" from the strings                         %
%   c) alters the words "hour" or "hours" to ":" in the strings           %
%   d) appends "0:" where no hours exist in the durations                 %
%   e) calculates the travelling time in minutes (to return it as output) %
%                                                                         %
% by:                 Alexandros Tzanetos  © 2022                         %
%-------------------------------------------------------------------------%
function [TravellingTimesConverted] = convertingDownloadedTimes2TravellingTimes(TravellingTimes)

if ~isa(class(TravellingTimes),'char')
    fprintf('The input should be a table of string data.\nCheck the input data and re-run the script.\n')
    return
end

% Delete "min" or "mins" from the strings
withoutMinsString = strrep(TravellingTimes,' mins','');
withoutMinString = strrep(withoutMinsString,' min','');

% Alter "hour" or "hours" to ":" in the strings
withoutHourString = strrep(withoutMinString,' hour ',':');
withoutHoursString = strrep(withoutHourString,' hours ',':');

% Append "0:" where no hours exist in the durations
withoutHoursString(~contains(withoutHoursString,':')) = append('0:',withoutHoursString(~contains(withoutHoursString,':')));

% Format the above table in datetime format
times2Datetime = datetime(withoutHoursString,'InputFormat','HH:mm');

% Calculate the duration in minutes
TravellingTimesConverted = hour(times2Datetime).*60 + minute(times2Datetime) + second(times2Datetime)./60;

