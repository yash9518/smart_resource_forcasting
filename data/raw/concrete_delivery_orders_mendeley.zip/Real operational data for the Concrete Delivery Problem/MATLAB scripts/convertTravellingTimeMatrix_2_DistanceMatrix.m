%-------------------------------------------------------------------------%
%         Convert the Travelling Time Matrix to Distance Matrix           %
%                                                                         %
% Run this file to convert a given Travelling Time Matrix (TTM) to a      %
% Distance Matrix (DM).                                                   %
%                                                                         %
% Input :                                                                 %
% (note that inputs are not passed in the function but the user is asked  %
% to provide them within the process)                                     %
% - averageTruckSpeed        : the average truck's speed                  %
% - plants_travelling_matrix : the travelling time matrix corresponding   %
%                              to the trips between Plants                %
% - prod2constr_matrix       : the travelling time matrix corresponding   %
%                              to the trips between Plants and            %
%                              Construction Sites.                        %
%                                                                         %
% Output:                                                                 %
% - DistanceMatrix       : the instance's corresponding distance matrix   %
%                                                                         %
% This script:                                                            %
%   a) loads the required tables by asking the user to locate them in the %
%      folders                                                            %
%   b) calculates how many trucks of each capacity type exist at each     %
%      Plant                                                              %
%   c) creates the AvailableTrucksPerPlant table containing the           %
%      information above and asks the user to save the output             %
%                                                                         %
% by:                 Alexandros Tzanetos  © 2023                         %
%-------------------------------------------------------------------------%

function [DistanceMatrix] = convertTravellingTimeMatrix_2_DistanceMatrix()

%% Travelling Time Matrix

% Locate the mat-file including the Plants data:
disp('Select the file "Plants.mat".')
[Plants_fileName, Plants_filePath] = uigetfile('*.mat','Select the file "Plants.mat".');
Plants_fullFileName = fullfile(Plants_filePath, Plants_fileName);

% Loading the plants' travelling matrix
load(Plants_fullFileName, 'plants_travelling_matrix')

% Locate the mat-file including the orders data:
disp('Select the instance file.')
[instance_fileName, instance_filePath] = uigetfile('*.mat','Select the instance file.');
instance_fullFileName = fullfile(instance_filePath, instance_fileName);

% Loading the Production-to-Construction-Sites travelling matrix and the
% instance's specifications
load(instance_fullFileName,'prod2constr_matrix')

% Creating a construction sites' travelling matrix
construction_sites_matrix = Inf .* ones(height(prod2constr_matrix));
% ----------------------------------------------------------------
% note that it's filled with INF values because travelling between
% construction sites is prohibited!
% ----------------------------------------------------------------
construction_sites_matrix(logical(eye(size(construction_sites_matrix)))) = 0;
% ---------------------------------------------------------------
% and the main diagonal of the matrix should be filled with zeros
% ---------------------------------------------------------------

% Constructing the Travelling Time Matrix
TravellingTimeMatrix = [plants_travelling_matrix   prod2constr_matrix'; ...
                        prod2constr_matrix         construction_sites_matrix];

% % Considering the GoogleTravelTimeMultiplier for travelling times
% TravellingTimeMatrix = TravellingTimeMatrix .* GoogleTravelTimeMultiplier;

%% Average Truck's Speed

answer = questdlg('Do you want to use the predefined average truck''s speed?',...
                  'Saving Output',...
                  'YES','No, I want to use another value','No, I want to use another value');
switch answer
    case 'YES'
        averageTruckSpeed = 0.36; % km/m
    case 'NO'
        prompt = "Please, type the value for the average truck''s speed: ";
        averageTruckSpeed = input(prompt);
end

%% Calculating the Distance Matrix

DistanceMatrix = TravellingTimeMatrix .* averageTruckSpeed;